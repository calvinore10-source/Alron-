# Site Alron — mise en ligne gratuite sur GitHub Pages

Ce dossier est prêt à être déposé **tel quel à la racine** d'un dépôt GitHub.
Contrairement à la version pour la Forge, il n'y a pas de sous-dossier
`public/` : tous les fichiers (`index.html`, `assets/`, `legal/`...) sont
directement au premier niveau, comme GitHub Pages l'attend par défaut.

## 1. À compléter avant publication

Le site est fonctionnel mais contient encore des **placeholders** à remplacer
dans `index.html` :

| Élément | Repère dans le fichier | À remplacer par |
|---|---|---|
| Email de contact | `votre-email@exemple.fr` (2 occurrences) | votre adresse réelle |
| Lien Facebook | `VotrePageAlron` (2 occurrences) | l'URL de votre page |
| Lien Ko-fi | `VotrePseudoKofi` (2 occurrences) | votre lien Ko-fi |
| Archive de l'application | `telechargement/alron.zip` | déposez-y le .zip **compilé** (voir `telechargement/LISEZ-MOI.txt` — l'archive source seule ne suffit pas, il faut lancer `npm run build`) |
| Notice utilisateur | `notice/notice-alron.pdf` | votre notice au format PDF |

Astuce : dans un éditeur, cherchez `exemple.fr`, `VotrePageAlron` et
`VotrePseudoKofi` dans `index.html` pour retrouver toutes les occurrences.

## 2. Publier sur GitHub Pages (gratuit, ~5 minutes)

1. Créez un compte gratuit sur https://github.com si vous n'en avez pas.
2. Cliquez sur **New repository**. Nommez-le par exemple `alron`. Cochez
   **Public** (obligatoire pour un Pages gratuit sur un compte personnel).
3. Une fois le dépôt créé, ouvrez-le puis cliquez sur **Add file > Upload
   files**. Glissez-déposez **tout le contenu de ce dossier** (pas le dossier
   lui-même, son contenu : `index.html`, `assets/`, `legal/`, `notice/`,
   `telechargement/`, `.nojekyll`) directement à la racine.
   - Le fichier `.nojekyll` est invisible dans l'explorateur de fichiers
     classique : dans GitHub, activez l'affichage des fichiers cachés lors de
     l'upload, ou ajoutez-le séparément via **Add file > Create new file** en
     tapant `.nojekyll` comme nom (contenu vide). Il empêche GitHub de essayer
     d'interpréter le site comme un site Jekyll, ce qui n'est pas nécessaire ici.
4. Validez le commit ("Commit changes").
5. Allez dans **Settings > Pages** (menu de gauche).
6. Sous **Build and deployment > Source**, choisissez **Deploy from a
   branch**. Sous **Branch**, choisissez `main` et le dossier `/ (root)`,
   puis **Save**.
7. Patientez 1 à 2 minutes : l'URL du site s'affiche en haut de cette même
   page, du type :
   `https://VOTRE-PSEUDO.github.io/alron/`

Chaque nouvelle modification poussée sur la branche `main` republie le site
automatiquement en quelques dizaines de secondes.

## 3. Brancher un vrai nom de domaine plus tard (optionnel)

Si vous achetez un jour `alron.fr` (~5 à 15 €/an), rien à reconstruire :
1. Chez votre registrar, ajoutez un enregistrement DNS de type CNAME pointant
   `alron.fr` vers `VOTRE-PSEUDO.github.io`.
2. Dans **Settings > Pages** du dépôt GitHub, renseignez `alron.fr` dans le
   champ **Custom domain**.
3. Cochez **Enforce HTTPS** une fois le certificat généré (automatique,
   gratuit, quelques minutes).

## 4. Site 100% statique, aucune dépendance serveur

Ce dossier fonctionne identiquement sur GitHub Pages, GitLab Pages, Netlify,
Cloudflare Pages, ou tout hébergement mutualisé classique — aucune base de
données, aucun langage serveur (PHP, etc.) n'est nécessaire.
